/******************************************************************************
**
** gen-prime.c - prime number generator
** Tony Camuso
** Nov 13, 2011
**
** Generate a text file containing all the prime numbers between the two 
** numbers input by the user. 
**
** Inputs are limited to unsigned integers less than 2^32, and the difference
** between them is imited to 1000 decimal. 
**
** A text file is generated which contains a list of the prime numbers
** generated. 
**
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>	// qsort	
#include <math.h>	// sqrt
#include <string.h>	// memset
#include <limits.h> // UINT_MAX

#define MAX_DIFF 1000	// Max allowable difference between lower and upper
						// numbers.

typedef struct inputs_s{
	int argc;
	char **argv;
	unsigned int upper;
	unsigned int lower;
	char filename[64];
}
INPUTS;

enum {
	argOkay,
	argInvCnt,
	argInvNum,
	argInvDiff,
	filOkay,
	filOpenFail
};

char *error = "\nERROR: ";
char *errorMsg[] = {
	"",
	"Invalid number of arguments.\n\n",
	"Invalid number.\n\n",
	"Difference between lower and upper numbers is greater than 1000.\n\n"
};

/******************************************************
** Forward Function Prototype Declarations
******************************************************/
unsigned int getNextPrime(unsigned int prime);
int	validateInputs(INPUTS* inputs);
void usage();
int errorExit(int err);
int createOutFile(INPUTS *inputs, FILE** outFile);

///////////////////////////////////////////////////////////////////////////////
//
// main 
//
// Takes two arguments from the command line, converts them into integers, and
// finds all the prime numbers between them.
//
int main(int argc, char **argv)
{
	int status;
	int count = 0;
	unsigned int prime;
	unsigned int next;
	INPUTS inputs;
	FILE* outFile;

	inputs.argc = argc;
	inputs.argv = argv;

	if((status = validateInputs(&inputs)) != argOkay)
		return status;

	if((status = createOutFile(&inputs, &outFile)) != filOkay)
		return status;

	fprintf(outFile, "All the prime numbers from %d to %d\n\n", 
		inputs.lower, inputs.upper);

	for(prime = inputs.lower; prime < inputs.upper; ){
		next = getNextPrime(prime);

		if(next > prime && next <= inputs.upper){
			fprintf(outFile, "%10d\n", next);
			count++;
		}
		prime = next;
	}

	printf("Found %d prime numbers from %d to %d.\n"
		"See file %s in this directory\n"
		"for the list of prime numbers.\n\n",
		count, inputs.lower, inputs.upper, inputs.filename);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// createOutFile
//
// Globals : none
// Arguments
//	inputs - data structure of tyep INPUTS defined in this file
//	outFile - pointer to a pointer to a FILE struct. 
// Returns status
//
int createOutFile(INPUTS* inputs, FILE** outFile)
{
	sprintf(inputs->filename, "PrimesFrom-%d-to-%d.txt", 
		inputs->lower, inputs->upper);
	if((*outFile = fopen(inputs->filename, "w+")) == NULL){
		printf("\nCannot open file: %s\n\n", inputs->filename);
		return filOpenFail;
	}
	printf("\nOpened file %s\n", inputs->filename);
	return filOkay;
}

///////////////////////////////////////////////////////////////////////////////
//
// validateInputs
//
// Globals : none
// Arguments
//	inputs - data structure of type INPUTS defined in this file
// Returns status
//
int validateInputs( INPUTS* inputs)
{
	unsigned int temp;
	int status;

	if(inputs->argc != 3)
		return(errorExit(argInvCnt));

	status = sscanf(inputs->argv[1], "%10d", &inputs->lower);
	if((status == 0) || (status == EOF) || (inputs->lower > UINT_MAX))
		return(errorExit(argInvNum));

	status = sscanf(inputs->argv[2], "%10d", &inputs->upper);
	if((status == 0) || (status == EOF) || (inputs->upper > UINT_MAX))
		return(errorExit(argInvNum));

	// If the user input the lower and upper in the wrong order, we'll just flip
	// them around rather than complain.
	//
	if(inputs->lower > inputs->upper){
		temp = inputs->lower;
		inputs->lower = inputs->upper;
		inputs->upper = temp;
	}

	if((inputs->upper - inputs->lower) > MAX_DIFF)
		return(errorExit(argInvDiff));

	return argOkay;
}

///////////////////////////////////////////////////////////////////////////////
//
// getNextPrime
//
// Recursive function to Find the next prime number up from the one passed. 
//
// Globals : none
// Arguments
//	prime - a prime number number
// Returns the next prime number
//
unsigned int getNextPrime(unsigned int prime)
{
	unsigned int next = prime;
	int index;
	
	// If caller passes a number less than 2, which is the lowest prime
	// number, then assume the caller wants the lowest prime number, and 
	// return 2.
	//
	if(next < 2)
		return 2;

	// If the caller passed an even number, make it an odd number.
	//
	if(next % 2 == 0)
		next += 1;
	else
		next += 2;
	
	for(index = 3; index <= sqrt(next); index += 2)
		if(next % index == 0)
			next = getNextPrime(next);

	return next;
}

int errorExit(int err)
{
		printf("%s%s", error, errorMsg[err]);
		usage();
		return err;
}

void usage()
{
	printf(
"\ngen-prime - prime number generator\n\n"
"This program will generate a text file containing a list of the prime\n"
"numbers between two numbers provided by the user.\n\n"
"usage: gen-prime lower upper\n\n"
"\tlower - the number from which to start generating prime numbers\n"
"\tupper - the number from which to stop generating prime numbers\n\n"
"The numbers input by the user are limited to the maximum value of \n"
"unsized int in the machine on which this program is executed.\n\n"
"Maximum value of int on this machine is %d\n\n"
"The difference between upper and lower is limited to 1000 decimal\n\n.",
UINT_MAX);
}

